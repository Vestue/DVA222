﻿// See https://aka.ms/new-console-template for more information

using assignment1_n_puzzle;

Game nPuzzle = new Game();