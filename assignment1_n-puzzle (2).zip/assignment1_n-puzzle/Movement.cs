namespace assignment1_n_puzzle;

public enum Movement
{
    Up,
    Down,
    Left,
    Right
}